import sys
import os
import argparse
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QFileDialog, QPushButton, QLabel, QVBoxLayout, QWidget, QStatusBar, QListWidget, QListWidgetItem, QHBoxLayout, QCheckBox, QTextEdit, QTreeView, QFileSystemModel, QSplitter, QMessageBox
)
from PyQt5.QtCore import Qt, pyqtSignal, QObject
from viewer import ViewerWidget
from util import mesh_from_path
from converter import saveobj, savegltf, parse_mesh # Import necessary functions
'''savecast, saveiqe, savepmx,'''  
from extractor import unpack
import threading

class ConsoleOutputHandler(QObject):
    text_output = pyqtSignal(str)

    def write(self, text):
        self.text_output.emit(text)

    def flush(self):
        pass  # Required for proper file-like behavior

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('NPK/EXPK Extractor and Mesh Viewer')
        self.setGeometry(100, 100, 1200, 800)

        # Initialize GUI components
        self.initUI()

        # Initialize the console output handler
        self.console_handler = ConsoleOutputHandler()
        self.console_handler.text_output.connect(self.append_console_output)

    def initUI(self):
        # Central widget and main layout
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        main_layout = QVBoxLayout(main_widget)

        # Splitter for dividing folder tree, file list, and viewer
        splitter = QSplitter(Qt.Horizontal)

        # Folder tree view with filtering for compatible files
        self.folder_tree = QTreeView()
        self.folder_model = QFileSystemModel()
        self.folder_model.setRootPath('')
        self.folder_model.setNameFilters(self.get_supported_extensions())
        self.folder_model.setNameFilterDisables(False)
        self.folder_tree.setModel(self.folder_model)
        self.folder_tree.setRootIndex(self.folder_model.index(''))
        self.folder_tree.clicked.connect(self.on_tree_view_clicked)

        splitter.addWidget(self.folder_tree)

        # List widget to display compatible files
        self.file_list_widget = QListWidget()
        self.file_list_widget.itemSelectionChanged.connect(self.on_file_selected)

        splitter.addWidget(self.file_list_widget)

        # Viewer for .mesh files
        self.viewer = ViewerWidget()

        splitter.addWidget(self.viewer)

        splitter.setSizes([250, 250, 700])

        main_layout.addWidget(splitter)

        # Console output area with adjusted height
        self.console_output = QTextEdit(self)
        self.console_output.setReadOnly(True)
        self.console_output.setFixedHeight(150)
        main_layout.addWidget(self.console_output)

        # Buttons and checkbox
        button_layout = QHBoxLayout()

        self.load_button = QPushButton('Load Folder', self)
        self.load_button.clicked.connect(self.load_folder)
        button_layout.addWidget(self.load_button)

        self.save_obj_button = QPushButton('Save OBJ', self)
        self.save_obj_button.clicked.connect(lambda: self.save_mesh('obj'))
        button_layout.addWidget(self.save_obj_button)

        self.save_gltf_button = QPushButton('Save GLTF', self)
        self.save_gltf_button.clicked.connect(lambda: self.save_mesh('gltf'))
        button_layout.addWidget(self.save_gltf_button)

        self.unpack_button = QPushButton('Unpack', self)
        self.unpack_button.clicked.connect(self.start_unpack)
        button_layout.addWidget(self.unpack_button)

        self.batch_obj_button = QPushButton('Batch OBJ', self)
        self.batch_obj_button.clicked.connect(lambda: self.batch_save_mesh('obj'))
        button_layout.addWidget(self.batch_obj_button)

        self.batch_gltf_button = QPushButton('Batch GLTF', self)
        self.batch_gltf_button.clicked.connect(lambda: self.batch_save_mesh('gltf'))
        button_layout.addWidget(self.batch_gltf_button)

        # Checkbox for unpacking the entire folder
        self.unpack_entire_folder_checkbox = QCheckBox('Unpack Entire Folder', self)
        button_layout.addWidget(self.unpack_entire_folder_checkbox)

        main_layout.addLayout(button_layout)

        # Status bar
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)

    def get_supported_extensions(self):
        # Define the supported file formats
        extensions = ['*.mesh', '*.npk']  # Include .npk for unpacking
        return extensions

    def on_tree_view_clicked(self, index):
        path = self.folder_model.filePath(index)
        if os.path.isdir(path):
            self.list_files_in_folder(path)

    def list_files_in_folder(self, folder_path):
        self.file_list_widget.clear()
        valid_extensions = tuple(ext.replace('*', '') for ext in self.get_supported_extensions())
        for file_name in os.listdir(folder_path):
            if file_name.lower().endswith(valid_extensions):
                item = QListWidgetItem(file_name)
                item.setData(Qt.UserRole, os.path.join(folder_path, file_name))
                self.file_list_widget.addItem(item)

    def load_folder(self):
        options = QFileDialog.Options()
        folder_path = QFileDialog.getExistingDirectory(self, "Select Folder", options=options)
        if folder_path:
            self.folder_tree.setRootIndex(self.folder_model.index(folder_path))
            self.list_files_in_folder(folder_path)
            self.folder_path = folder_path
            self.status_bar.showMessage(f'Selected Folder: {os.path.basename(folder_path)}')

    def on_file_selected(self):
        selected_items = self.file_list_widget.selectedItems()
        if not selected_items:
            return
        selected_item = selected_items[0]
        file_path = selected_item.data(Qt.UserRole)
        if file_path.endswith('.mesh'):
            mesh = mesh_from_path(file_path)
            self.viewer.load_mesh(mesh)
            self.current_mesh = mesh
            self.current_file_path = file_path

            # Display the number of faces and bones
            face_count = len(mesh['face'])
            bone_count = len(mesh['bone_name']) if 'bone_name' in mesh else 0
            self.status_bar.showMessage(f"Loaded {os.path.basename(file_path)}: {face_count} faces, {bone_count} bones.")

    def save_mesh(self, mode):
        if hasattr(self, 'current_mesh') and hasattr(self, 'current_file_path'):
            save_path, _ = QFileDialog.getSaveFileName(self, f"Save as {mode.upper()}", self.current_file_path.replace('.mesh', f'.{mode}'), f"{mode.upper()} Files (*.{mode})")
            if not save_path:  # Check if the save_path is valid
                self.status_bar.showMessage('Save operation canceled.')
                return  # Exit the function if the path is not valid

            print(f"Saving {mode.upper()} to: {save_path}")  # Debug statement to print the file path
            try:
                if mode == 'obj':
                    saveobj(self.current_mesh, save_path)  # Save as OBJ
                elif mode == 'gltf':
                    savegltf(self.current_mesh, save_path)  # Save as GLTF
                
                self.status_bar.showMessage(f'{mode.upper()} saved successfully!')
                QMessageBox.information(self, f'Save as {mode.upper()}', f'The mesh has been successfully saved as a {mode.upper()} file.')
            except Exception as e:
                self.status_bar.showMessage(f'Failed to save {mode.upper()}: {str(e)}')
                print(f"Failed to save {mode.upper()}: {e}")
        else:
            self.status_bar.showMessage('No mesh loaded to save.')
            QMessageBox.warning(self, f'Save as {mode.upper()}', 'Please load a mesh file first.')

    def batch_save_mesh(self, mode):
        if hasattr(self, 'folder_path'):
            folder = QFileDialog.getExistingDirectory(self, f"Select Folder to Save {mode.upper()}s")
            if folder:
                for i in range(self.file_list_widget.count()):
                    item = self.file_list_widget.item(i)
                    file_path = item.data(Qt.UserRole)
                    if file_path.endswith('.mesh'):
                        mesh = parse_mesh(file_path)
                        save_path = os.path.join(folder, os.path.basename(file_path).replace('.mesh', f'.{mode}'))
                        if mode == 'obj':
                            saveobj(mesh, save_path)  # Save as OBJ
                        elif mode == 'gltf':
                            savegltf(mesh, save_path)  # Save as GLTF
                self.status_bar.showMessage(f'Batch {mode.upper()} save completed!')
                QMessageBox.information(self, f'Batch Save as {mode.upper()}', f'All meshes have been successfully saved as {mode.upper()} files.')
        else:
            self.status_bar.showMessage('No folder loaded for batch saving.')
            QMessageBox.warning(self, f'Batch Save as {mode.upper()}', 'Please load a folder first.')

    def start_unpack(self):
        if hasattr(self, 'folder_path') and self.folder_path:
            if self.unpack_entire_folder_checkbox.isChecked():
                # Unpack the entire folder
                args = argparse.Namespace(path=self.folder_path, info=1, nxfn_file=False, no_nxfn=False, do_one=False, nxs3=False, force=False, delete_compressed=False)
                threading.Thread(target=self.run_unpack, args=(args,)).start()
            else:
                # Unpack selected files
                selected_items = self.file_list_widget.selectedItems()
                if not selected_items:
                    self.status_bar.showMessage('Error: No file selected')
                    return

                for item in selected_items:
                    file_path = item.data(Qt.UserRole)
                    args = argparse.Namespace(path=file_path, info=1, nxfn_file=False, no_nxfn=False, do_one=False, nxs3=False, force=False, delete_compressed=False)
                    threading.Thread(target=self.run_unpack, args=(args,)).start()

    def run_unpack(self, args):
        try:
            unpack(args, statusBar=self.status_bar)
            self.status_bar.showMessage('Unpacking completed')
        except Exception as e:
            self.status_bar.showMessage(f'Error: {str(e)}')
        finally:
            # Restore sys.stdout to its original state
            sys.stdout = sys.__stdout__

    def append_console_output(self, text):
        # Append the text to the console output widget
        self.console_output.append(text)
        # Scroll to the bottom to see the latest output
        self.console_output.ensureCursorVisible()

def main():
    app = QApplication(sys.argv)
    main_window = MainWindow()
    main_window.show()
    sys.exit(app.exec_())

if __name__ == '__main__':
    main()
